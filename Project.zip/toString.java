package com.company;

public interface toString {
    public String toString();
}
