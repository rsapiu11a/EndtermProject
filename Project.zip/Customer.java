package com.company;

public class Customer implements toString{

    private String customer_id;
    private String customer_unique_id;
    private String zip_code;
    private String customer_city;
    private String customer_state;

    public Customer(){ }

    public Customer(String customer_id, String customer_unique_id, String zip_code, String customer_city, String customer_state ){
        this.customer_id = customer_id;
        this.customer_unique_id = customer_unique_id;
        this.zip_code = zip_code;
        this.customer_city = customer_city;
        this.customer_state = customer_state;
    }

    public String getCustomer_id() {
        return customer_id;
    }

    public String getCustomer_unique_id(){
        return this.customer_unique_id;
    }

    public String getZip_code() {
        return zip_code;
    }

    public String getCustomer_city() {
        return customer_city;
    }

    public String getCustomer_state() {
        return customer_state;
    }

    public void setCustomer_id(String customer_id) {
        this.customer_id = customer_id;
    }

    public void setCustomer_unique_id(String customer_unique_id) {
        this.customer_unique_id = customer_unique_id;
    }

    public void setZip_code(String zip_code) {
        this.zip_code = zip_code;
    }

    public void setCustomer_city(String customer_city) {
        this.customer_city = customer_city;
    }

    public void setCustomer_state(String customer_state) {
        this.customer_state = customer_state;
    }

    public static String Order(String unique_id, Database database)  {
        int i = 0;
        while (!unique_id.equals(database.getCustomer().get(i).getCustomer_unique_id())){
            ++i;
        }
        int k = 0;
        while (!database.getCustomer().get(i).getCustomer_id().equals(database.getOrder().get(k).getCustomer_id()))
            ++k;

        return "My order's status: " + '\n' + database.getOrder().get(k).toString();

    }

    @Override
    public String toString() {
        return
                "customer_id = " + customer_id + '\n' +
                "customer_unique_id = " + customer_unique_id + '\n' +
                "zip_code = " + zip_code + '\n' +
                "customer_city = " + customer_city + '\n' +
                "customer_state = " + customer_state + '\n';
    }

}
