package com.company;

import java.util.List;
import java.util.Scanner;

public class Console {
    private static final Scanner scanner = new Scanner(System.in);
    private Console() {}


    public static String charIn(String prompt) {
        System.out.print(prompt);
        return scanner.next();
    }

    //-------------- Input validation ------------------


    //check if the input is integer and is in range
    public static int validateInt(String prompt, int min, int max) {
        int input;
        do {
            System.out.print(prompt);
            while (!scanner.hasNextInt()) {
                System.out.print(prompt);
                scanner.next();
            }
            input = scanner.nextInt();
        } while (!((input >= min) && (input <= max)));
        return input;
    }


    //check if the unique id is existed
    public static String validateCustomerID(List<Customer> CustomerList) {
        String id = charIn("Type in the customer unique ID : ");
        while (true) {
            for (Customer customer : CustomerList) {
                if (customer.getCustomer_unique_id().equals(id)) {
                    return id;
                }
            }
            id = charIn("The customer unique id is not existed, type another: ");
        }
    }
}
