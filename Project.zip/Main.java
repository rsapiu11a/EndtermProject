package com.company;

import java.math.BigDecimal;
import java.sql.*;
import java.util.*;
import java.sql.SQLException;
import static java.sql.DriverManager.getConnection;

public class Main {

    public static void main(String[] args) throws NoSuchElementException, SQLException {

        // Database Connection
        String connectionUrl = "jdbc:postgresql://localhost:5432/JavaProject";
        Connection con = getConnection(connectionUrl, "postgres", "123");
        ResultSet rs;
        Statement stmt = con.createStatement();

        Scanner sc = new Scanner(System.in);
        boolean cont = true;

        while (cont) {
            System.out.println("---------------- Main Menu----------------");


            System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------");
            System.out.println("1.Top 10 Product");
            System.out.println("2.To show the number of product orders purchased based on the states.");
            System.out.println("3.Payment value");
            System.out.println("4.To show my order");
            System.out.println("5.Exit");
            System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------");

            int choice1 = Console.validateInt("Selection (number): ", 1, 5);
            switch (choice1) {

                // Top 10 Product

                case 1 -> {
                    rs = stmt.executeQuery("SELECT  products.product_category_name, COUNT(*) FROM items, orders, products where  items.order_id=orders.order_id and products.product_id = items.product_id GROUP BY product_category_name ORDER BY COUNT(*) DESC limit 10;");
                    System.out.println("Top 10 Product");

                    System.out.println("Product name:                  " + "The number of orders: ");
                    while (rs.next()) {


                        System.out.println("               " + rs.getString("product_category_name") + "                  " + rs.getInt("count"));
                    }
                }


                // To show the number of product orders purchased based on the states.

                case 2 -> {
                    rs = stmt.executeQuery("SELECT  customers.customer_state, COUNT(*) FROM customers, orders where customers.customer_id=orders.customer_id GROUP BY customers.customer_state ORDER BY COUNT(*) DESC");

                    System.out.println("Geo Exploratory");

                    System.out.println("State name:                  " + "The number of orders: ");
                    while (rs.next()) {

                        System.out.println("               " + rs.getString("customer_state") + "                  " + rs.getInt("count"));
                    }
                }


                // Analysis Payment Value
                case 3 -> {
                    rs = stmt.executeQuery("select price, freight_value, order_item_id from items;");
                    System.out.println("Payment Value");

                    double sum = 0.0;
                    while (rs.next()) {

                        // To find all payment value
                        sum += (rs.getDouble("price") + rs.getDouble("freight_value"));
                    }
                    System.out.println("All payment value:  " + new BigDecimal(sum));


                    // To find value of 2016 year
                    sum = 0.0;
                    rs = stmt.executeQuery("select price, freight_value, order_item_id  from items where shipping_limit_date between '2016-01-01' and '2017-01-01';");
                    while (rs.next()) {
                        sum += (rs.getDouble("price") + rs.getDouble("freight_value"));
                    }
                    System.out.println("Payment value of 2016 year :  " +
                            new BigDecimal(sum));

                    // To find value of 2017 year
                    sum = 0.0;
                    rs = stmt.executeQuery("select price, freight_value, order_item_id from items where shipping_limit_date between '2017-01-01' and '2018-01-01';");
                    while (rs.next()) {
                        sum += (rs.getDouble("price") + rs.getDouble("freight_value"));

                    }
                    System.out.println("Payment value of 2017 year :  " + new BigDecimal(sum));

                    // To find value of 2018 year
                    sum = 0.0;
                    rs = stmt.executeQuery("select price, freight_value, order_item_id  from items where shipping_limit_date between '2018-01-01' and '2019-01-01';");
                    while (rs.next()) {
                        sum += (rs.getDouble("price") + rs.getDouble("freight_value"));
                    }

                    System.out.println("Payment value of 2018 year :  " + new BigDecimal(sum));

                }

                //  To show order for customers
                case 4 -> {
                    rs = stmt.executeQuery("select * from customers");

                    Database customers = new Database();

                    while (rs.next()) {

                        customers.addCustomer(new Customer(rs.getString("customer_id"), rs.getString("customer_unique_id"),
                                rs.getString("customer_zip_code_prefix"), rs.getString("customer_city"), rs.getString("customer_state")));


                    }
                    rs = stmt.executeQuery("select * from orders");

                    while (rs.next()) {

                        customers.addOrder(new Orders(rs.getString("order_id"), rs.getString("customer_id"),
                                rs.getString("order_status"), rs.getDate("order_purchase_timestamp"), rs.getDate("order_approved_at"),
                                rs.getDate("order_delivered_carrier_date"), rs.getDate("order_delivered_customer_date"), rs.getDate("order_estimated_delivery_date")));


                    }
                    String result = Console.validateCustomerID(customers.getCustomer());
                    System.out.println(Customer.Order(result, customers));
                }

                case 5 -> cont = false;
            }
        }
    }
}


