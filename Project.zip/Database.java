package com.company;
import java.util.*;
public class Database{
    private List<Customer> customers = new ArrayList<>();
    private List<Item> items = new ArrayList<>();
    private List<Orders> orders = new ArrayList<>();


    public void addCustomer(Customer customer){
        customers.add(customer);
    }
    public void addOrder(Orders orders){
        this.orders.add(orders);
    }
    public void addItem(Item item){this.items.add(item);}

    public List<Orders> getOrder(){return this.orders;}

    public List<Customer> getCustomer(){return this.customers;}

    public List<Item> getItems(){return this.items;}




}
